import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://apsc.nic.in/')

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_CCE (Prelim.)'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_CCE (Mains)'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_Scheme of Examination'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/h4_General Studies-I'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Read More'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/h5_General Studies-II'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/div_Paper-1                       Essay    _f16183'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Syllabus'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_CCE (Mains)'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_Direct Recruitment'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_Forms and Downloads'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_Recruitment Advertisements'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/span_APPLICATION START DATE15-06-2024'))

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/span_APPLY HERE'))

WebUI.click(findTestObject('Object Repository/Page_APSC  Home/a_Junior Legislative Counsel and Under Secr_0b6994'))

WebUI.click(findTestObject('Object Repository/Page_APSC  Home/span_05072024 Midnight'))

WebUI.click(findTestObject('Object Repository/Page_APSC  Home/span_LOG IN'))

WebUI.click(findTestObject('Object Repository/Page_APSC  Log In/button_Only For CSC User_digitalSevaBtn btn-block'))

WebUI.click(findTestObject('Object Repository/Page_Digitalseva Connect/input_Not readable Click Here to refresh_login'))

WebUI.click(findTestObject('Object Repository/Page_APSC  Home/button_Click Here'))

WebUI.click(findTestObject('Object Repository/Page_APSC  snc-Home/p_PhNo- 1800-572-23-43'))

WebUI.closeBrowser()

