import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://apsc.nic.in/')

WebUI.click(findTestObject('Object Repository/Page_Assam Public Service Commission/a_About Us'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/a_Vision and Mission'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/p_To select suitable candidates possessing _18e57c'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/div_Composition of the Commission'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/p_Combined Competitive Exam(CCE)'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/a_1) Junior Legislative Counsel and Under S_b68fae'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/td_Shri Chinmoy Nath, ACS'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/a_CCE (Prelim.)'))

WebUI.click(findTestObject('Page_Assam Public Service Commission/a_Scheme of Examination'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Download'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Download_1 (1)'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Preliminary'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_2020'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Syllabus'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_2022'))

WebUI.click(findTestObject('Object Repository/Page_APSC, CCE/a_Preliminary'))

WebUI.closeBrowser()

