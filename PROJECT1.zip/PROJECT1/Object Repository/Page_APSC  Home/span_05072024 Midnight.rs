<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_05072024 Midnight</name>
   <tag></tag>
   <elementGuidId>907c25f2-95e5-4c29-ae0c-49f695d17146</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Application End Date :'])[1]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.whats_new_content > span:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;05/07/2024 Midnight&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>be5238c5-1dde-4ed2-8bc6-b72d3f669635</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 05/07/2024 Midnight</value>
      <webElementGuid>3245010b-62ca-46b7-ba35-ec2d39c0b486</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[1]/app-root[1]/app-kpsc-landing[1]/div[@class=&quot;wrapper landing-wrapper&quot;]/div[@class=&quot;content_area&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;middle-panel animated fadeInUp&quot;]/div[@class=&quot;whats_new&quot;]/ul[1]/li[1]/div[@class=&quot;whats_new_content&quot;]/span[2]</value>
      <webElementGuid>20cff6be-65f6-45ce-bec6-c357689a4441</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application End Date :'])[1]/following::span[1]</value>
      <webElementGuid>3da6db77-0ef5-4fa5-98fc-f741f20797d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[11/2024(1)]'])[1]/following::span[2]</value>
      <webElementGuid>a22d226d-f308-4e48-82ba-15992f7e65ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jun'])[2]/preceding::span[1]</value>
      <webElementGuid>25984f11-ea2a-4101-98a1-617f8ad534bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[11/2024(2)]'])[1]/preceding::span[3]</value>
      <webElementGuid>25115b99-39ea-4f3d-8c87-a4b0784d8a10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='05/07/2024 Midnight']/parent::*</value>
      <webElementGuid>b519a4c1-b870-4779-838c-bebb624b678e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span[2]</value>
      <webElementGuid>e611a922-211a-4da5-ac49-213e8e80395f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' 05/07/2024 Midnight' or . = ' 05/07/2024 Midnight')]</value>
      <webElementGuid>cfa0ff72-5f22-4367-b81e-400d778083dd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
