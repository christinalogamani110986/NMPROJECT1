<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Junior Legislative Counsel and Under Secr_0b6994</name>
   <tag></tag>
   <elementGuidId>656d72a6-9585-4dd8-84c0-d9186a24dd8f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Jun'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;click to view pdf&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam [11/2024(1)]&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c15417b8-f8ec-4a00-b43e-2df7447e819d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>click to view pdf</value>
      <webElementGuid>460d09cf-b597-419d-bb66-8ad6631361a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>69e16fdb-2c56-495a-a5c8-51c06e7c17dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://apscdocuments.s3.ap-south-1.amazonaws.com/Production/Advertisement/AdvertisementDocument/08dc8390-ecef-447f-8f1d-c8fbc418e453/638529905653437190_Advt_No_11_2024.pdf?X-Amz-Expires=604800&amp;X-Amz-Algorithm=AWS4-HMAC-SHA256&amp;X-Amz-Credential=AKIAXR6R4BEDBVFTPTRI/20240613/ap-south-1/s3/aws4_request&amp;X-Amz-Date=20240613T084915Z&amp;X-Amz-SignedHeaders=host&amp;X-Amz-Signature=3cff059d9cdea742888824650deb7bb9c1b333765457f176118afa866f862dd7</value>
      <webElementGuid>b7ac3b49-e4ba-4443-828c-052d73d0371e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>download</name>
      <type>Main</type>
      <value>download</value>
      <webElementGuid>fbd89b1a-8a35-42d9-baee-538fc91b97e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam [11/2024(1)]</value>
      <webElementGuid>814bec7a-07cd-4c92-90a8-5438a6fa30c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[1]/app-root[1]/app-kpsc-landing[1]/div[@class=&quot;wrapper landing-wrapper&quot;]/div[@class=&quot;content_area&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;middle-panel animated fadeInUp&quot;]/div[@class=&quot;whats_new&quot;]/ul[1]/li[1]/div[@class=&quot;whats_new_content&quot;]/a[1]</value>
      <webElementGuid>28f9440a-3536-421b-a4e3-bdb241271e82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jun'])[1]/following::a[1]</value>
      <webElementGuid>b0506a64-4d50-4bf4-b551-e6ca9f93154f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Whats New'])[1]/following::a[1]</value>
      <webElementGuid>601236a9-12ec-4780-9552-e93477c22a79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application End Date :'])[1]/preceding::a[1]</value>
      <webElementGuid>760d2cf1-d849-430f-aa3c-d49099b7c782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam']/parent::*</value>
      <webElementGuid>127e5059-8f0c-40dd-a567-ba152fb4c159</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://apscdocuments.s3.ap-south-1.amazonaws.com/Production/Advertisement/AdvertisementDocument/08dc8390-ecef-447f-8f1d-c8fbc418e453/638529905653437190_Advt_No_11_2024.pdf?X-Amz-Expires=604800&amp;X-Amz-Algorithm=AWS4-HMAC-SHA256&amp;X-Amz-Credential=AKIAXR6R4BEDBVFTPTRI/20240613/ap-south-1/s3/aws4_request&amp;X-Amz-Date=20240613T084915Z&amp;X-Amz-SignedHeaders=host&amp;X-Amz-Signature=3cff059d9cdea742888824650deb7bb9c1b333765457f176118afa866f862dd7')]</value>
      <webElementGuid>6c85b025-73a6-4e01-a6b1-cb3f4d21cdb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a</value>
      <webElementGuid>7c8f89a4-5b98-4363-8716-048d5066abee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@title = 'click to view pdf' and @href = 'https://apscdocuments.s3.ap-south-1.amazonaws.com/Production/Advertisement/AdvertisementDocument/08dc8390-ecef-447f-8f1d-c8fbc418e453/638529905653437190_Advt_No_11_2024.pdf?X-Amz-Expires=604800&amp;X-Amz-Algorithm=AWS4-HMAC-SHA256&amp;X-Amz-Credential=AKIAXR6R4BEDBVFTPTRI/20240613/ap-south-1/s3/aws4_request&amp;X-Amz-Date=20240613T084915Z&amp;X-Amz-SignedHeaders=host&amp;X-Amz-Signature=3cff059d9cdea742888824650deb7bb9c1b333765457f176118afa866f862dd7' and (text() = ' Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam [11/2024(1)]' or . = ' Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam [11/2024(1)]')]</value>
      <webElementGuid>bc014c9a-6f69-46cb-8b18-e31cffcd7202</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
