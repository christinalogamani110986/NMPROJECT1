<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Click Here</name>
   <tag></tag>
   <elementGuidId>815fb671-605d-4f8f-9e59-4a446f15a476</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Application End Date :'])[3]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.danger-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Click Here&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>66612b57-e35d-4273-ae26-9ff58d0af57e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>danger-button</value>
      <webElementGuid>8ca25e8e-1e13-448e-a832-67d8d2a5e0b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>49d99d8d-5af0-4312-b8d5-0b6330a7f170</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[1]/app-root[1]/app-kpsc-landing[1]/div[@class=&quot;wrapper landing-wrapper&quot;]/div[@class=&quot;content_area&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;middle-panel animated fadeInUp&quot;]/div[@class=&quot;whats_new&quot;]/ul[1]/p[@class=&quot;center&quot;]/button[@class=&quot;danger-button&quot;]</value>
      <webElementGuid>3ba15ece-8775-470f-866c-bbffa7be2a73</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application End Date :'])[3]/following::button[1]</value>
      <webElementGuid>22533e9b-4791-4ba4-bba1-db0625f19b0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[11/2024(3)]'])[1]/following::button[1]</value>
      <webElementGuid>dad78bb0-99fa-44dc-a3fc-f48376a8ac48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='to Login for the post of Night Chowkidar.'])[1]/preceding::button[1]</value>
      <webElementGuid>3a5006bf-9a40-477c-9b50-888bf13f52a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guidelines for Candidates'])[1]/preceding::button[1]</value>
      <webElementGuid>16b8f01a-9192-4538-a12b-c7ed39e19d6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click Here']/parent::*</value>
      <webElementGuid>32358ad7-a0e3-4376-8354-a5a95d88e2d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>e42e7256-2c43-409b-aac4-c037d8d9055d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>53ebdf2e-1959-441e-9960-ea4471de87ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
