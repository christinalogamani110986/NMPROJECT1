<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Combined Competitive Examination</name>
   <tag></tag>
   <elementGuidId>e77c01f4-c6f1-4110-81f4-c708ef74d7e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='showcase']/div/div/div/div/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.display-2.pt-5.mt-5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Combined Competitive Examination&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>c8821515-88de-4239-bbff-cd092f0b2449</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>display-2 pt-5 mt-5</value>
      <webElementGuid>0e29a4a2-d5f2-496e-8c17-e45209ad2899</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Combined Competitive Examination</value>
      <webElementGuid>6a3228d6-ae1e-4f17-ad15-0803e1ab6f28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;showcase&quot;)/div[@class=&quot;showcase-ovrly text-white&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col text-center&quot;]/h1[@class=&quot;display-2 pt-5 mt-5&quot;]</value>
      <webElementGuid>36f37811-5561-4718-9c94-e5ac100ea6e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='showcase']/div/div/div/div/h1</value>
      <webElementGuid>948c542c-aaed-4568-b9a6-a4f3e32206d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Main'])[1]/following::h1[1]</value>
      <webElementGuid>39c570fb-b6f9-4823-950f-e5f8032370c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preliminary'])[1]/following::h1[1]</value>
      <webElementGuid>cf9d76fb-bc7c-42d3-abb1-5079101fc1e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[1]/preceding::h1[1]</value>
      <webElementGuid>01c74a5c-c54a-4acc-94d0-6230335684ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preliminary Examination'])[1]/preceding::h1[1]</value>
      <webElementGuid>84ac4d67-feaa-44f9-bf40-b3327d2ccbb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Combined Competitive Examination']/parent::*</value>
      <webElementGuid>735fe90f-0f62-436c-80d7-ae7e193985e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>09843b81-a909-4098-9f5f-30ebfa7d8aea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Combined Competitive Examination' or . = 'Combined Competitive Examination')]</value>
      <webElementGuid>1988c7a9-6d3a-4786-b5e0-170ef1a455c2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
