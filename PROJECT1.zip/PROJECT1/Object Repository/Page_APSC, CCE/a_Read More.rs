<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Read More</name>
   <tag></tag>
   <elementGuidId>cdd29aa5-d539-48ab-bad7-06909dc38b99</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='show_button']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#show_button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Read More &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3f07c70e-68eb-4c5a-a4c4-698c65fd8ed7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>show_button</value>
      <webElementGuid>777d0da1-1b0b-4385-b703-0a4e5e02316e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://personnel.assam.gov.in/sites/default/files/swf_utility_folder/departments/personnel_webcomindia_org_oid_3/menu/document/apsc_rules_2019-compressed_compressed.pdf</value>
      <webElementGuid>6def509a-fda3-49d9-9a50-6227fe3315ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-outline-primary btn-lg text-white</value>
      <webElementGuid>7c0a3e3a-a9d4-4630-b919-863f5a679666</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
             Read More 
          </value>
      <webElementGuid>c797a035-f14e-4306-b0eb-7873d00031e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;show_button&quot;)</value>
      <webElementGuid>833dace1-9930-4c17-a83f-593bc9bbb4c4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='show_button']</value>
      <webElementGuid>8c5ef694-ae17-4ade-94b5-7f17f6ec5ad7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='showcase']/div/div/div/div/a</value>
      <webElementGuid>0565d7ec-b2ba-42c4-95fb-5712803fe5b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Read More')]</value>
      <webElementGuid>cbf957ff-8c3d-4048-b5e3-1d0abbfff329</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Combined Competitive Examination'])[1]/following::a[1]</value>
      <webElementGuid>02580bb7-0960-4ea4-a826-75fd8d535af8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Main'])[1]/following::a[1]</value>
      <webElementGuid>0fe9448d-2be0-4916-853f-988f56b39403</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preliminary Examination'])[1]/preceding::a[1]</value>
      <webElementGuid>5dc91dff-127b-41cf-aa3a-18f0a39b821a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Studies-I'])[1]/preceding::a[1]</value>
      <webElementGuid>6ae6bd96-fab7-4fc1-8c14-ccc33ac15eaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Read More']/parent::*</value>
      <webElementGuid>02194086-9deb-40fc-adf5-fb1edf213b4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://personnel.assam.gov.in/sites/default/files/swf_utility_folder/departments/personnel_webcomindia_org_oid_3/menu/document/apsc_rules_2019-compressed_compressed.pdf')]</value>
      <webElementGuid>14a25870-ddc3-466a-a979-e9aebf44d7b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/a</value>
      <webElementGuid>a81aef93-5f0e-4fe8-a7eb-01ee20da30cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@id = 'show_button' and @href = 'https://personnel.assam.gov.in/sites/default/files/swf_utility_folder/departments/personnel_webcomindia_org_oid_3/menu/document/apsc_rules_2019-compressed_compressed.pdf' and (text() = '
             Read More 
          ' or . = '
             Read More 
          ')]</value>
      <webElementGuid>5d640302-3e81-4a72-93bc-0c46fd2e969c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
