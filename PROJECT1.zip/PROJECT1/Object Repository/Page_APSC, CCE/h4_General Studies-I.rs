<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_General Studies-I</name>
   <tag></tag>
   <elementGuidId>19995a58-cd5d-4ba8-837a-aaeb45683c8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='author-header']/div/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-sm-6 > h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#cce_pre >> internal:role=heading[name=&quot;General Studies-I&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>ac1d009e-98ac-4e84-9e84-3a90f213af26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>General Studies-I</value>
      <webElementGuid>ee57c3f9-3394-42fb-8265-c426dd05975d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cce_pre&quot;)/div[@class=&quot;container&quot;]/div[@id=&quot;author-header&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6&quot;]/h4[1]</value>
      <webElementGuid>7da19f07-cff1-487b-9d90-39a5627d95d4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='author-header']/div/div/h4</value>
      <webElementGuid>ba06e31d-11e0-4f1c-b762-1ffa6bfe68a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preliminary Examination'])[1]/following::h4[1]</value>
      <webElementGuid>c6b35f3c-0f25-49fd-9a58-f812075de452</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[1]/following::h4[1]</value>
      <webElementGuid>a66ca18a-0975-4ea9-b982-00a052bae374</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Studies-II'])[1]/preceding::h4[1]</value>
      <webElementGuid>3614b473-dddc-4818-b8b9-5393df8d4f50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[1]/preceding::h4[2]</value>
      <webElementGuid>6deea6fe-d431-440d-99ff-11ae7dec0ec5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='General Studies-I']/parent::*</value>
      <webElementGuid>5adeb3c2-2e37-40e5-84d5-ae2601e69418</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/h4</value>
      <webElementGuid>b2d07682-a236-4445-aa35-12f51928e528</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'General Studies-I' or . = 'General Studies-I')]</value>
      <webElementGuid>e8faf107-bde4-4b22-8491-572c7a8d7f8e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
