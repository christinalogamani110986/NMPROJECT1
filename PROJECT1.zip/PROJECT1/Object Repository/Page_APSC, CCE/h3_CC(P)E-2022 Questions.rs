<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_CC(P)E-2022 Questions</name>
   <tag></tag>
   <elementGuidId>dd62afbe-a251-4e8f-b309-686603fe7918</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='prelim-details']/div/div/div[2]/div/div/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;CC(P)E-2022 Questions&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>d6072889-251e-40d0-836c-485b10548506</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CC(P)E-2022 Questions</value>
      <webElementGuid>b4ff26ff-8c26-48eb-a5a0-586069a943b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;home&quot;)/section[@id=&quot;prelim-details&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row py-1&quot;]/div[@class=&quot;col-lg-4 col-md-6 pb-3&quot;]/div[@class=&quot;card author-details border-info&quot;]/div[@class=&quot;card-header bg-primary text-white&quot;]/h3[1]</value>
      <webElementGuid>a0c6e276-fe50-4c94-b9a0-d47316e6e045</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='prelim-details']/div/div/div[2]/div/div/h3</value>
      <webElementGuid>6f7b03ab-ca7e-4ec7-adde-ee254e4fedc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[2]/following::h3[1]</value>
      <webElementGuid>0e600e82-fe30-477d-8640-84565175d35a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Studies-II'])[2]/following::h3[1]</value>
      <webElementGuid>758de2c8-8d9a-4633-81b3-acb4b4a2c5e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Studies-I'])[3]/preceding::h3[1]</value>
      <webElementGuid>5be2c95b-5d09-4b99-8dfb-4600c13d83c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[3]/preceding::h3[1]</value>
      <webElementGuid>3fdbe111-00e4-4d3c-90d5-54254599ce4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CC(P)E-2022 Questions']/parent::*</value>
      <webElementGuid>784eb045-1a5a-4b0f-bb9c-d1a049b64c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/h3</value>
      <webElementGuid>14f4e627-1258-4427-a330-34bbe58e0663</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'CC(P)E-2022 Questions' or . = 'CC(P)E-2022 Questions')]</value>
      <webElementGuid>49486c97-70df-40d4-bd56-14837ba1e972</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
