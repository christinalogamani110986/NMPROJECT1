<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_General Studies-II</name>
   <tag></tag>
   <elementGuidId>e2cb43bf-fca8-41c2-88e7-e1abe604b8a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='prelim-details']/div/div/div/div/div[2]/h5[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.card-title.pt-1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;General Studies-II&quot;s] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>bcab2dae-26ef-4db0-9a1b-0faeccf859ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-title pt-1</value>
      <webElementGuid>94bb0bb5-f209-40be-8ce4-33bd04a2369c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>General Studies-II</value>
      <webElementGuid>0c08d7cc-8433-46a2-8095-2a4086d3b769</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;home&quot;)/section[@id=&quot;prelim-details&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row py-1&quot;]/div[@class=&quot;col-lg-4 col-md-6 pb-3&quot;]/div[@class=&quot;card author-details border-info&quot;]/div[@class=&quot;card-body&quot;]/h5[@class=&quot;card-title pt-1&quot;]</value>
      <webElementGuid>674bce82-eb64-4bf2-bf6d-10de6a1f1380</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='prelim-details']/div/div/div/div/div[2]/h5[2]</value>
      <webElementGuid>7fe73e47-674b-4084-a5fc-7db4ae1e42d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/following::h5[1]</value>
      <webElementGuid>45ff3e8d-d5aa-426b-b73f-d2b0526da715</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Studies-I'])[2]/following::h5[1]</value>
      <webElementGuid>ffd050d7-17a7-4288-b85b-8d6c56ed278c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[2]/preceding::h5[1]</value>
      <webElementGuid>26a35a68-3f0a-4fc7-b8d4-8dfd20c13d71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(P)E-2022 Questions'])[1]/preceding::h5[1]</value>
      <webElementGuid>64459fb8-cd9c-4847-bb5e-d189194bbb2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5[2]</value>
      <webElementGuid>0b2f6fd3-b991-4c4c-a5da-9170ad205ac7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'General Studies-II' or . = 'General Studies-II')]</value>
      <webElementGuid>988ac87d-d611-4948-996e-d2cb4213dbf9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
