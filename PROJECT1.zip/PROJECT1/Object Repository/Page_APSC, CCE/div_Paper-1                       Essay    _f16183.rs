<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Paper-1                       Essay    _f16183</name>
   <tag></tag>
   <elementGuidId>31b9f4ae-3462-49d1-b92f-9c447248ff34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//section[@id='prelim-details']/div/div/div)[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Paper-1 Essay 250 Marks | 3 Hours Syllabus Previous Year Question Papers 2020 20&quot;i >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c96e4fef-58aa-477e-85ed-63fbc2805b63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-lg-4 col-md-6 pb-3</value>
      <webElementGuid>c9c6e9a6-0379-4b67-9864-d4706b592461</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
         
            Paper-1 
          
            Essay
            
            250 Marks | 3 Hours
            
            Syllabus
             Previous Year Question Papers 
            2020 2022
          
        
      </value>
      <webElementGuid>3474c63f-6ce1-46db-8b19-53af0c6c3a10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;home&quot;)/section[@id=&quot;prelim-details&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row py-1&quot;]/div[@class=&quot;col-lg-4 col-md-6 pb-3&quot;]</value>
      <webElementGuid>64957000-4102-4a60-8f93-4d59d285e718</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//section[@id='prelim-details']/div/div/div)[4]</value>
      <webElementGuid>41e0a94e-3414-4cf5-8ba2-acd58e2be957</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/following::div[4]</value>
      <webElementGuid>2a09e7ac-ef5b-40a3-b1a1-1e66d0beb51d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interview'])[1]/following::div[8]</value>
      <webElementGuid>a039b78e-cbd0-4074-a5be-a09d6a604e02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[5]/div/div/div</value>
      <webElementGuid>cb79c365-7431-45e7-8fbf-852a91fcb0d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
         
            Paper-1 
          
            Essay
            
            250 Marks | 3 Hours
            
            Syllabus
             Previous Year Question Papers 
            2020 2022
          
        
      ' or . = '
         
            Paper-1 
          
            Essay
            
            250 Marks | 3 Hours
            
            Syllabus
             Previous Year Question Papers 
            2020 2022
          
        
      ')]</value>
      <webElementGuid>5b364807-25a1-4d52-aa40-17ebefb86a65</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
