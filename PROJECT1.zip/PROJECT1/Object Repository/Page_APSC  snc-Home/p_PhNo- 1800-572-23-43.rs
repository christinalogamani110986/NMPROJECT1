<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_PhNo- 1800-572-23-43</name>
   <tag></tag>
   <elementGuidId>c13b4d67-03fb-441c-a444-b886f16ad3a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Helpdesk for Candidates'])[1]/following::p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;PhNo- 1800-572-23-43&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c5cc4bb2-96b0-4583-a297-fb29ba0e1961</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>center</value>
      <webElementGuid>0295282a-8be5-45c2-862b-65314bc3b03a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PhNo- 1800-572-23-43 </value>
      <webElementGuid>8d15ddba-c1bf-45d8-b7ba-1afb06fe52d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[1]/app-root[1]/app-snc-landing[1]/div[@class=&quot;wrapper landing-wrapper&quot;]/div[@class=&quot;content_area&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;left-panel animated fadeInUp&quot;]/div[@class=&quot;helpline_box&quot;]/div[@class=&quot;helpline_body&quot;]/p[@class=&quot;center&quot;]</value>
      <webElementGuid>97932634-5f40-416a-bbf1-ca9c71651be6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Helpdesk for Candidates'])[1]/following::p[2]</value>
      <webElementGuid>ae7a1243-400f-436d-9be5-75c91c1a3046</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A++'])[1]/following::p[2]</value>
      <webElementGuid>22240122-0323-47ca-a68a-cc991611703b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='cceapsc[at]gmail[dot]com'])[1]/preceding::p[1]</value>
      <webElementGuid>c6e6100a-c4cf-47c1-8dba-97af9bfd71ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GRAS Helpdesk'])[1]/preceding::p[3]</value>
      <webElementGuid>b403be14-a6da-4c72-8ed5-803a93fc0a5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PhNo- 1800-572-23-43']/parent::*</value>
      <webElementGuid>1b09b0c1-ccba-4214-a1a0-60355e842194</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]</value>
      <webElementGuid>f5133b00-5471-4cb8-8a0c-ee96ffe74aa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'PhNo- 1800-572-23-43 ' or . = 'PhNo- 1800-572-23-43 ')]</value>
      <webElementGuid>5b72b95b-91d2-40e1-a42d-4b54e1cf6ed0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
