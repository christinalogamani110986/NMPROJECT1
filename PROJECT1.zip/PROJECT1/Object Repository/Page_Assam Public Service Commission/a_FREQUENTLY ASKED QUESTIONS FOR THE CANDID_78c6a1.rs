<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_FREQUENTLY ASKED QUESTIONS FOR THE CANDID_78c6a1</name>
   <tag></tag>
   <elementGuidId>fa72ba2c-09ce-4cae-bc9c-236d998d27bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[3]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(3) > td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a654f3a2-4145-42cf-bd9e-0666ab9bc912</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>faq/FAQ_EWS_21072022.pdf</value>
      <webElementGuid>c5f2bdd1-cf44-4b43-b6be-8ffd9c3f2762</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS) </value>
      <webElementGuid>95dd2851-195c-4f01-bc05-38ba3b6bd814</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[3]/td[2]/a[1]</value>
      <webElementGuid>766706f2-ea08-4152-bc90-d095970a30f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[3]/td[2]/a</value>
      <webElementGuid>6e11f8c7-7014-4693-923f-d8a6d696dfb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS)')]</value>
      <webElementGuid>bf2c8821-51cf-41eb-a521-a4bd2d3196b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQs on Common Mistakes When Filling OMR Sheets'])[1]/following::a[1]</value>
      <webElementGuid>2ea77220-9696-4bc0-b42d-a68d643dbc5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/following::a[2]</value>
      <webElementGuid>440486ff-ee3b-46dd-8650-930169e97cd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::a[1]</value>
      <webElementGuid>cdd09b69-a77f-4e4c-b1fb-36ac9796fcc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(Prel.)Examination-2022'])[1]/preceding::a[2]</value>
      <webElementGuid>e2ebd685-a7e7-4454-b2b7-68885ea00337</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS)']/parent::*</value>
      <webElementGuid>59abc109-2847-4a5f-b7a6-8e66519b2478</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'faq/FAQ_EWS_21072022.pdf')]</value>
      <webElementGuid>74b08cec-9095-4f44-8f96-5b169bb99e36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]/a</value>
      <webElementGuid>767edc72-42e6-4713-ad24-5f37c8822c0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'faq/FAQ_EWS_21072022.pdf' and (text() = ' FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS) ' or . = ' FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS) ')]</value>
      <webElementGuid>a6fef870-43f7-480b-8d33-408eb880a9ac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
