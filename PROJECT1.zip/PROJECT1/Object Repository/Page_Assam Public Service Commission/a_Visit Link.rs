<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Visit Link</name>
   <tag></tag>
   <elementGuidId>73740e82-4083-48bf-93c8-a9a58dd1dd34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[9]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(9) > td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Visit Link&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>41ecf0c6-c6d1-43c4-8be6-2ca7ff1867e5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>answer_keys.asp</value>
      <webElementGuid>75be5a30-de64-4fbc-ab88-d44cd719c41f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Visit Link</value>
      <webElementGuid>d35ec6f7-8665-4243-a168-95b6d96aecc9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[9]/td[2]/a[1]</value>
      <webElementGuid>4a3c88cb-235f-4abe-aea6-5edff8392452</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[9]/td[2]/a</value>
      <webElementGuid>34075a4b-397e-4f8c-a477-50dc85c44330</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Visit Link')]</value>
      <webElementGuid>d2f800d3-6256-416f-a9dd-7ea7b0663653</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Answer Keys'])[2]/following::a[1]</value>
      <webElementGuid>d4ad8b3d-55a0-4ff1-8b18-d36ae7cd0160</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[8]/following::a[1]</value>
      <webElementGuid>a29a1d00-df84-4fbe-b518-621b8804ff0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::a[1]</value>
      <webElementGuid>94f9d1c1-7ac0-4d9d-b7b3-21999e38d0a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(Prel.)Examination-2022'])[1]/preceding::a[2]</value>
      <webElementGuid>a4464249-7e8c-4471-ba90-43df3b949db6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Visit Link']/parent::*</value>
      <webElementGuid>de9538f9-e78d-405d-bfa9-915fdc5f846a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'answer_keys.asp')])[2]</value>
      <webElementGuid>e82e1893-dce7-4a8a-9305-8afd6b644ebe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[9]/td[2]/a</value>
      <webElementGuid>6bd4b863-b557-4799-ba13-a86b1adb7776</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'answer_keys.asp' and (text() = 'Visit Link' or . = 'Visit Link')]</value>
      <webElementGuid>26b2cf38-7bf9-4acd-8ef2-d8e4c0dfdc35</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
