<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Vision and Mission</name>
   <tag></tag>
   <elementGuidId>94e85c3e-4fc5-42ac-a55b-f204f7b6a4b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myNavbar']/ul/li[2]/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu > li:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Vision and Mission&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>697829bf-fd71-4179-b3b2-60dac1faa591</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>commission.asp</value>
      <webElementGuid>2fc26a50-ee1a-4d98-b2f9-2f790a9441d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Vision and Mission</value>
      <webElementGuid>6b281814-6df0-453d-90d8-11f705a064af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myNavbar&quot;)/ul[@class=&quot;nav nav-tabs nav-justified&quot;]/li[@class=&quot;dropdown open&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[2]/a[1]</value>
      <webElementGuid>4164d27f-47c4-484b-9aba-f5bfe64a02e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>79366f2d-8e11-4050-9f05-fdb2a89541e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Vision and Mission')]</value>
      <webElementGuid>2a7e95d4-7aba-4489-853c-5427ba889fd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Commission'])[1]/following::a[1]</value>
      <webElementGuid>404994c3-b9bd-4ccf-8064-c71ff2eb6b82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::a[3]</value>
      <webElementGuid>8cb6e44d-7157-41b8-a60c-b7ff9aa9043f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Historical Perspective'])[1]/preceding::a[1]</value>
      <webElementGuid>cedc6203-cdf6-4112-a032-177bfbc3ac2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Constitutional Provision'])[1]/preceding::a[2]</value>
      <webElementGuid>ef90d1a1-4733-43c8-a2ca-fea0058359de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Vision and Mission']/parent::*</value>
      <webElementGuid>42dbeaf1-b844-4574-95bd-358f0d6e0a09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'commission.asp')])[2]</value>
      <webElementGuid>b78b7c48-e904-4009-8c6e-7837a2c503b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[2]/a</value>
      <webElementGuid>8414f5c3-7ea2-4c47-9939-8d9e6709ba15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'commission.asp' and (text() = 'Vision and Mission' or . = 'Vision and Mission')]</value>
      <webElementGuid>b697a5a8-5e87-4712-81fa-c965b6057e23</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
