<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_APPLICATION START DATE15-06-2024</name>
   <tag></tag>
   <elementGuidId>207b2b0d-0ac7-4168-b2e6-8e48d51ca348</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='advertisement']/tbody/tr[2]/td[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > span.label.label-danger</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;APPLICATION START DATE:15-06-2024&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d9816a0d-df3a-4b19-8cbc-5f0cf95189b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-danger</value>
      <webElementGuid>3869a0ab-718f-4893-8753-249f46d1393e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>APPLICATION START DATE:15-06-2024</value>
      <webElementGuid>f05e423b-9dde-4b40-be18-5c3f9ff94ed9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;advertisement&quot;)/tbody[1]/tr[@class=&quot;advt_rw&quot;]/td[2]/span[@class=&quot;label label-danger&quot;]</value>
      <webElementGuid>5d29a57a-8f43-445f-aa15-fe4df5241eb8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='advertisement']/tbody/tr[2]/td[2]/span</value>
      <webElementGuid>e112309b-189a-46e7-a4d6-b14f63e076cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY HERE'])[1]/following::span[1]</value>
      <webElementGuid>6241361d-1533-443c-a093-6ae3fa488e50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Closing Date'])[1]/following::span[2]</value>
      <webElementGuid>46443d72-4252-4e22-a4fc-40488ebc4f51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY HERE'])[2]/preceding::span[1]</value>
      <webElementGuid>c1660e07-4fce-4105-962f-a41ca1641b6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION START DATE:15-06-2024'])[2]/preceding::span[2]</value>
      <webElementGuid>31dc8ba9-0f15-427a-b635-0753ad61189f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='APPLICATION START DATE:15-06-2024']/parent::*</value>
      <webElementGuid>3b3c172d-9722-49d2-b2ab-8d926fc6fb59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/span</value>
      <webElementGuid>5ed3dcf7-3e3c-455c-a524-4b315fd4abfc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'APPLICATION START DATE:15-06-2024' or . = 'APPLICATION START DATE:15-06-2024')]</value>
      <webElementGuid>0568eacf-c538-4add-bd7b-eaedb8b91979</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
