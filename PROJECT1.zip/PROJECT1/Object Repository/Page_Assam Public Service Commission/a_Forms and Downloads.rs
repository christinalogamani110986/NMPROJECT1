<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Forms and Downloads</name>
   <tag></tag>
   <elementGuidId>08eb13b3-32ce-4cb7-ad56-43ddf59f36a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myNavbar']/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(6) > a.nav-items</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Forms and Downloads&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7f7b5198-cd13-49bf-a0f4-562812a3a3df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-items</value>
      <webElementGuid>b6a2ae27-4d9e-498b-96c6-b2f23a598611</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>downloads.asp#downloads</value>
      <webElementGuid>5619164b-45da-4b4d-9931-58cb7f9aff83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Forms and Downloads</value>
      <webElementGuid>f69542e0-c0b5-407a-8326-db736d46f069</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myNavbar&quot;)/ul[@class=&quot;nav nav-tabs nav-justified&quot;]/li[6]/a[@class=&quot;nav-items&quot;]</value>
      <webElementGuid>aad81942-7b38-42d7-8784-03a33551ab88</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul/li[6]/a</value>
      <webElementGuid>c8ecee2f-505b-4066-9b1d-880b20745afb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Forms and Downloads')]</value>
      <webElementGuid>b1d83a2f-c7d6-4888-a7ea-0cf3f923551b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[3]/following::a[1]</value>
      <webElementGuid>6de96a36-abd1-499f-a09c-e1d444cf961c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scheme of Examination'])[3]/following::a[2]</value>
      <webElementGuid>d9d09d03-a9f2-4a05-b31c-ef58f0c577e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::a[1]</value>
      <webElementGuid>b68784d5-9acf-45d9-88c4-554a56f29701</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/preceding::a[2]</value>
      <webElementGuid>41967616-6244-4bdf-8d75-71ed877f7685</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Forms and Downloads']/parent::*</value>
      <webElementGuid>851ac2d1-c77a-4934-9e0d-bf22dbe9baef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'downloads.asp#downloads')]</value>
      <webElementGuid>24e68f9c-17c3-4c45-9e7e-7f32ba87191b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/a</value>
      <webElementGuid>1cc80bcf-4cc9-4729-a4ea-db0c346a9f7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'downloads.asp#downloads' and (text() = 'Forms and Downloads' or . = 'Forms and Downloads')]</value>
      <webElementGuid>3f7b66c8-6c4b-455d-8dda-1824964c0ccd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
