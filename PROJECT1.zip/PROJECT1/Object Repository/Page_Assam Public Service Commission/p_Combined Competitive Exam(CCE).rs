<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Combined Competitive Exam(CCE)</name>
   <tag></tag>
   <elementGuidId>07b3c311-796a-4f1f-b4bc-30ab52cd0dc3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='footer-info']/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.bg-primary.list-head</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Combined Competitive Exam(CCE)&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>d2ac6cca-3daa-4803-b70d-600f9fed7720</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bg-primary list-head</value>
      <webElementGuid>d118cf7b-84a0-4dc7-b8c9-ca47d3502cad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Combined Competitive Exam(CCE)</value>
      <webElementGuid>489aa352-db88-494d-96a3-b13050943dc7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;footer-info&quot;)/div[@class=&quot;col-sm-3&quot;]/p[@class=&quot;bg-primary list-head&quot;]</value>
      <webElementGuid>1ee6da2d-4660-4619-b449-336123aa1a3e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='footer-info']/div/p</value>
      <webElementGuid>ef8e1b9d-ac46-4317-8892-2380871ffae2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri Chinmoy Nath, ACS'])[1]/following::p[1]</value>
      <webElementGuid>5f63f04c-7e71-40fb-b155-6f5ecf639a0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Principal Controller Of Examinations'])[1]/following::p[1]</value>
      <webElementGuid>45228196-2be1-40a7-9d49-a742b01d4c00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::p[1]</value>
      <webElementGuid>2b2aa8ce-798e-4e9d-8c56-6439ac2381cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(Prel.)Examination-2022'])[1]/preceding::p[1]</value>
      <webElementGuid>0d9f54c5-6550-4908-89da-2390d5e1d2d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Combined Competitive Exam(CCE)']/parent::*</value>
      <webElementGuid>7ac98816-9231-49fa-a551-967b3fa9252a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/p</value>
      <webElementGuid>dda71232-4061-4d23-90ed-cd394704cfee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Combined Competitive Exam(CCE)' or . = 'Combined Competitive Exam(CCE)')]</value>
      <webElementGuid>701c0e34-4f18-4b6c-9325-97309b2a53cd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
