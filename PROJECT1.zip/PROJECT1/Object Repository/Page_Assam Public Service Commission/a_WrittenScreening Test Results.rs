<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_WrittenScreening Test Results</name>
   <tag></tag>
   <elementGuidId>dcfbe159-49e6-4d89-884b-56e6c3c2fcfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='imp-links']/div/div[2]/div/a[9]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Written/Screening Test Results&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cc74abc8-5291-424e-8cc3-bc4780293db0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>scr_tst_result_2024.asp#scr_test</value>
      <webElementGuid>302049b2-0669-4f83-b6f7-e88d6aa8bc6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item imp-link</value>
      <webElementGuid>e26ae6fb-5f66-4ece-bb21-78099c1ad2a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Written/Screening Test Results</value>
      <webElementGuid>3c3ddd17-0ede-432d-b12d-e34aa35027e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;imp-links&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;list-group&quot;]/a[@class=&quot;list-group-item imp-link&quot;]</value>
      <webElementGuid>41106fbb-14bc-4005-b224-646d84658384</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='imp-links']/div/div[2]/div/a[9]</value>
      <webElementGuid>b8ab9f79-7cbe-4d4d-8153-5e65232a6652</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Written/Screening Test Results')]</value>
      <webElementGuid>d4688248-b01a-4e22-b3ad-c6d1bc198780</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Question Papers'])[1]/following::a[1]</value>
      <webElementGuid>7cf8f449-9a73-4837-8eec-06e3fa564921</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Answer Keys'])[1]/following::a[2]</value>
      <webElementGuid>3fe1cd7b-a708-4fed-b1e0-bd3a1825e1b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Results'])[1]/preceding::a[1]</value>
      <webElementGuid>46fd997d-a182-4c1f-b779-07d6a31fdeaf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/preceding::a[2]</value>
      <webElementGuid>9eac81c2-7af2-4685-8527-68bf1f45bbc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Written/Screening Test Results']/parent::*</value>
      <webElementGuid>d90b107c-ae3f-44fc-9c00-79832b9a0fc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'scr_tst_result_2024.asp#scr_test')]</value>
      <webElementGuid>8cceb9f1-56f4-4489-9fb0-c106fe7928ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[9]</value>
      <webElementGuid>035d936c-a0a4-47d3-bacd-db86165968fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'scr_tst_result_2024.asp#scr_test' and (text() = 'Written/Screening Test Results' or . = 'Written/Screening Test Results')]</value>
      <webElementGuid>8a22ed8c-e1bc-4f4b-8044-57f9101275bd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
