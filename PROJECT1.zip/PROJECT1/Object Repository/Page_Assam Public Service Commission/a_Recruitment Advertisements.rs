<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Recruitment Advertisements</name>
   <tag></tag>
   <elementGuidId>70426b2f-c413-4cd4-838c-777102b8592a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='imp-links']/div/div[2]/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.list-group-item.imp-link</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Recruitment Advertisements&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>dabc0708-6a70-40b4-b6d4-d9dc2a9c8a5d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>advt_2024.asp#advertisement</value>
      <webElementGuid>69e22a95-ee77-4460-969b-d8b86578cd60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item imp-link</value>
      <webElementGuid>ece2fa24-7c92-4abf-acc9-d2a148abfdf2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Recruitment Advertisements</value>
      <webElementGuid>e8a0fa17-0fd8-4fed-9db3-01e2e55bc673</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;imp-links&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;list-group&quot;]/a[@class=&quot;list-group-item imp-link&quot;]</value>
      <webElementGuid>2151fe20-8e7b-4310-86c9-844be4c25850</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='imp-links']/div/div[2]/div/a</value>
      <webElementGuid>15292c5b-99ca-4399-ac61-f34afb6cc0c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Recruitment Advertisements')]</value>
      <webElementGuid>01fb4432-ca1e-47a3-96cc-b68922a8c234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Important Links'])[1]/following::a[1]</value>
      <webElementGuid>0d4910c0-5d87-41df-8109-7a6dac0581d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/following::a[1]</value>
      <webElementGuid>dd9ad9a9-3031-4b4b-a8ae-cf1bf6d43065</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[4]/preceding::a[1]</value>
      <webElementGuid>fc7d9db9-2d88-40b7-b712-afb63c0462b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notifications'])[1]/preceding::a[2]</value>
      <webElementGuid>3ad0a575-24b9-4737-87d0-62db8923cb3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Recruitment Advertisements']/parent::*</value>
      <webElementGuid>2f7c5b88-92a8-4974-b141-408552b79b76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'advt_2024.asp#advertisement')]</value>
      <webElementGuid>5f6962ab-9b86-4287-8834-5664bd51be55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/a</value>
      <webElementGuid>5bc6748e-533f-4671-85c7-0496a1e35487</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'advt_2024.asp#advertisement' and (text() = 'Recruitment Advertisements' or . = 'Recruitment Advertisements')]</value>
      <webElementGuid>6aaff7b3-6e46-461e-a379-a3a2ec55b4b6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
