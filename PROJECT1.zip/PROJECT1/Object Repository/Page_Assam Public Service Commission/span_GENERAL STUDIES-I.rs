<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_GENERAL STUDIES-I</name>
   <tag></tag>
   <elementGuidId>4a17c82a-2719-4bf0-bb1b-6c11bc5a3ff7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[4]/td[3]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(4) > td:nth-of-type(3) > a > span.label.label-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;GENERAL STUDIES-I&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b3f0bcfb-2c6f-4ff5-8279-406f145b7794</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-primary</value>
      <webElementGuid>ade78e6a-224d-40d0-95b9-a82032912bdf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GENERAL STUDIES-I</value>
      <webElementGuid>2fa6b0b9-93a0-4adb-a71b-436946198c3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[4]/td[3]/a[1]/span[@class=&quot;label label-primary&quot;]</value>
      <webElementGuid>a8abca31-a9b8-40f0-a085-e4a672286af1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[4]/td[3]/a/span</value>
      <webElementGuid>8ce0fdaf-951e-4e76-a8b7-ddb551320110</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENERAL STUDIES'])[1]/following::span[1]</value>
      <webElementGuid>c7c38865-c9ea-4663-8b2a-192e0cd4c20d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENERAL STUDIES-II'])[1]/preceding::span[1]</value>
      <webElementGuid>329a226b-b6f7-4604-9f20-164ceb352333</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENERAL STUDIES'])[2]/preceding::span[2]</value>
      <webElementGuid>22e9e803-61e4-467f-909c-1044404021e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='GENERAL STUDIES-I']/parent::*</value>
      <webElementGuid>0e7c2f12-dab4-4858-981b-3364715ea1d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td[3]/a/span</value>
      <webElementGuid>fd8e20fa-bb0b-47f9-be97-0432e235ccee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'GENERAL STUDIES-I' or . = 'GENERAL STUDIES-I')]</value>
      <webElementGuid>1070711a-a843-455e-b3d5-46a7a79cf2e3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
