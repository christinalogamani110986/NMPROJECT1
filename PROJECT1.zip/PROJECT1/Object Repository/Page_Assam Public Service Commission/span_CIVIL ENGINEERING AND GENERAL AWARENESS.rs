<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_CIVIL ENGINEERING AND GENERAL AWARENESS</name>
   <tag></tag>
   <elementGuidId>1e6e4b88-b863-40f3-af84-360f0c473eea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[3]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.label.label-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;CIVIL ENGINEERING AND GENERAL AWARENESS&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4d088d06-2172-4ae6-ab90-a332ea03315e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-primary</value>
      <webElementGuid>c2f669bb-db19-4c16-8b7e-9edc175a35ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CIVIL ENGINEERING AND GENERAL AWARENESS</value>
      <webElementGuid>51e430c2-e413-4a8b-8c14-e4eaed376481</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[2]/td[3]/a[1]/span[@class=&quot;label label-primary&quot;]</value>
      <webElementGuid>58a14c42-3977-4358-b296-c36e28fd1665</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[3]/a/span</value>
      <webElementGuid>aba6004f-d12f-4740-aa60-9084b3fda444</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Name &amp; Question Papers'])[1]/following::span[1]</value>
      <webElementGuid>6bf9b1c5-4957-4a9e-a5dc-12d8352c02a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advt. No.'])[1]/following::span[1]</value>
      <webElementGuid>b4610056-b648-4e2e-aa97-d65b8e6f2d13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENERAL STUDIES'])[1]/preceding::span[1]</value>
      <webElementGuid>12d61945-7134-455e-9799-622c70fa5910</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CIVIL ENGINEERING AND GENERAL AWARENESS']/parent::*</value>
      <webElementGuid>aecf5769-65f5-46c6-820e-185a22ee1eb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[3]/a/span</value>
      <webElementGuid>5447928b-3ffc-497e-8f12-42051c448112</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'CIVIL ENGINEERING AND GENERAL AWARENESS' or . = 'CIVIL ENGINEERING AND GENERAL AWARENESS')]</value>
      <webElementGuid>52fcbcd3-c3cb-4709-9100-d5a21998981f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
