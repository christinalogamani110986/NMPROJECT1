<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Shri Chinmoy Nath, ACS</name>
   <tag></tag>
   <elementGuidId>da0cf9e8-cda8-4b73-b18f-c8755c4f6eda</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[3]/div[2]/table/tbody/tr[7]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(7) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Shri Chinmoy Nath, ACS&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>979cf5b2-f303-465b-a459-bc96d511da7b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shri Chinmoy Nath, ACS</value>
      <webElementGuid>072481dc-59a7-4911-a354-45d261a0f75c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel-group&quot;]/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered&quot;]/tbody[1]/tr[7]/td[2]</value>
      <webElementGuid>5147ae4b-ef85-41e2-9a41-43390bf66f6d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[3]/div[2]/table/tbody/tr[7]/td[2]</value>
      <webElementGuid>e6af4c86-c359-4aae-92fc-956dffb4d6a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Principal Controller Of Examinations'])[1]/following::td[1]</value>
      <webElementGuid>dd35b6b3-6a4b-49ca-aaf2-cc644ada1e0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Smti Chandana Mahanta, ACS'])[1]/following::td[2]</value>
      <webElementGuid>0af1e8de-e88b-4af5-ac61-f4bb03f3d8f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::td[1]</value>
      <webElementGuid>89178ab1-3a25-432e-8abc-118a5bdfb860</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(Prel.)Examination-2022'])[1]/preceding::td[1]</value>
      <webElementGuid>7275e8c0-4ee1-4292-8f39-e2ec0c80c0bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shri Chinmoy Nath, ACS']/parent::*</value>
      <webElementGuid>57209149-061e-476b-8ff8-ea1695c324ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[7]/td[2]</value>
      <webElementGuid>8e568141-5b39-454c-8727-0a98688743e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Shri Chinmoy Nath, ACS' or . = 'Shri Chinmoy Nath, ACS')]</value>
      <webElementGuid>0ed8f50e-b2a2-486c-a799-a3eb96e117a4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
