<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_FAQs on Common Mistakes When Filling OMR Sheets</name>
   <tag></tag>
   <elementGuidId>d2762fe3-7b96-4a9e-8ea2-94e956bf5a53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;FAQs on Common Mistakes When Filling OMR Sheets&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cab4d1cc-8b2a-4ed5-a5b3-1e87d4713a62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>faq/OMR_FAQ.pdf</value>
      <webElementGuid>ff3e0846-f65b-4f82-b0d6-4e3e0dfb0836</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> FAQs on Common Mistakes When Filling OMR Sheets </value>
      <webElementGuid>72ae0a53-16ae-4be0-9a9c-7f18998482fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[2]/td[2]/a[1]</value>
      <webElementGuid>8a84d3e5-b403-4677-b0d9-50a5eedcbfe1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[2]/a</value>
      <webElementGuid>7d344ab1-6f8f-41c2-81ce-4e19c0165ae7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'FAQs on Common Mistakes When Filling OMR Sheets')]</value>
      <webElementGuid>9ee44acd-5222-4f89-961b-999d62c98c88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/following::a[1]</value>
      <webElementGuid>1e6cf68c-d650-4f26-ae67-119bf2f7b911</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sl. No.'])[1]/following::a[1]</value>
      <webElementGuid>0b9d45cd-b7e8-4dac-a49e-23b923348da4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FREQUENTLY ASKED QUESTIONS FOR THE CANDIDATES BELONGING TO ECONOMICALLY WEAKER SECTION (EWS)'])[1]/preceding::a[1]</value>
      <webElementGuid>8f08b1cd-e252-4424-baa0-1d46deab02ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::a[2]</value>
      <webElementGuid>09bd9ab7-7ca4-413f-a259-3a9f6078d876</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='FAQs on Common Mistakes When Filling OMR Sheets']/parent::*</value>
      <webElementGuid>62466ae3-b967-4786-9ccc-ecf02139e5f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'faq/OMR_FAQ.pdf')]</value>
      <webElementGuid>494e9748-2aa4-4367-a869-c76ae6701c55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
      <webElementGuid>4f307337-430a-4fa5-8cc0-e5b95174e92c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'faq/OMR_FAQ.pdf' and (text() = ' FAQs on Common Mistakes When Filling OMR Sheets ' or . = ' FAQs on Common Mistakes When Filling OMR Sheets ')]</value>
      <webElementGuid>650631b5-6137-4f58-99e1-54abcc2f9044</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
