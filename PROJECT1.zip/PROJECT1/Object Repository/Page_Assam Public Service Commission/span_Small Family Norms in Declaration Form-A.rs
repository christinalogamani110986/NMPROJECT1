<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Small Family Norms in Declaration Form-A</name>
   <tag></tag>
   <elementGuidId>a99d4413-993c-4259-946f-07e098fa9bbf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr/td/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.label.label-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Small Family Norms in Declaration Form-A&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>efdea87a-5601-409d-a627-0566d1ea820f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-primary</value>
      <webElementGuid>4b18497f-1fd9-40bd-9569-1dfae6ff600f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Small Family Norms in Declaration Form-A</value>
      <webElementGuid>2e00b26f-3af0-4aa2-9c7b-cf3772d299f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[1]/td[1]/span[@class=&quot;label label-primary&quot;]</value>
      <webElementGuid>76017582-9e9b-433d-a8e8-5c471b156ed8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr/td/span</value>
      <webElementGuid>9ef078e7-a56b-4010-b45e-48a998b11791</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application Forms and Downloads'])[1]/following::span[1]</value>
      <webElementGuid>84ce1d46-9265-4b71-8556-9245f406a634</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/following::span[1]</value>
      <webElementGuid>36285aac-2106-4a7d-8c3e-959e661073af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/preceding::span[1]</value>
      <webElementGuid>a3d3564a-59c9-4db9-ad14-605634dd04d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Direct Recruitment(DR) (New Form)'])[1]/preceding::span[1]</value>
      <webElementGuid>472f5da0-c254-4bc2-81b5-9eaa5d774542</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Small Family Norms in Declaration Form-A']/parent::*</value>
      <webElementGuid>c0afda30-5b57-43b3-9466-cd50598161e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/span</value>
      <webElementGuid>3b593a01-9131-4dfd-b6a3-b9196126cfb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Small Family Norms in Declaration Form-A' or . = 'Small Family Norms in Declaration Form-A')]</value>
      <webElementGuid>20d59131-7ff4-41fd-a3ff-529889cd7397</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
