<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Corrigendum regarding recruitment to the _1cc53a</name>
   <tag></tag>
   <elementGuidId>516ed154-2534-437f-9a66-cfb532961668</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='corrigendums']/tbody/tr[2]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>77d02a0b-6369-441a-9205-86970efc0f4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>misc_2024/63PSC_CON_Exam_23_2023-2024.pdf</value>
      <webElementGuid>f1ff14b6-4eb4-4671-b4e1-a323e5b74370</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)</value>
      <webElementGuid>5d080b01-b941-463c-ad8f-ecc6a2966354</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;corrigendums&quot;)/tbody[1]/tr[2]/td[2]/a[1]</value>
      <webElementGuid>1bfcc208-fe1b-47a7-89ef-cd69a2cc834c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='corrigendums']/tbody/tr[2]/td[2]/a</value>
      <webElementGuid>f2a53ae5-882f-46be-8921-973b32bcafe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)')]</value>
      <webElementGuid>0169f063-e39d-425b-af15-12adf29c87c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Date'])[1]/following::a[1]</value>
      <webElementGuid>9e32ab39-0ebc-4380-ba33-b21125c0f9d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corrigendum'])[1]/following::a[1]</value>
      <webElementGuid>d144cc45-e3bc-4823-9792-34a077665abd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assam Public Services Combined Competitive Examination (Amendment) Rules, 2019'])[1]/preceding::a[12]</value>
      <webElementGuid>8b1521dd-2148-41e5-8f77-10c887b43e6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CC(Prel.)Examination-2022'])[1]/preceding::a[13]</value>
      <webElementGuid>67cb5ade-45cb-41aa-969f-f024b3aec78e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)']/parent::*</value>
      <webElementGuid>7b09caa6-170b-4fb4-b00f-85f0f4025c7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'misc_2024/63PSC_CON_Exam_23_2023-2024.pdf')]</value>
      <webElementGuid>d67c4aec-87d8-4ccd-8bc2-fb1721efc79a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
      <webElementGuid>4b1a91f3-6adb-4e34-a6e4-e30ed9ebe6a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'misc_2024/63PSC_CON_Exam_23_2023-2024.pdf' and (text() = 'Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)' or . = 'Corrigendum regarding recruitment to the post of Cultural Development Officer under Directorate of Cultural Affairs, Assam under Cultural Affairs Department (Advt. No. 25/2023 dtd. 05/09/2023)')]</value>
      <webElementGuid>1a0a3f87-3bf4-4120-ab35-550778ba277b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
