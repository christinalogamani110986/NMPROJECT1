<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_1) Junior Legislative Counsel and Under S_b68fae</name>
   <tag></tag>
   <elementGuidId>1d559228-b2d6-4eb6-b19e-d203e98561b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='footer-info']/div[2]/marquee/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.scroll-updates > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;1) Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam 2) Legal Assistant to Legal Remembrancer and Under Secretary to the Government of Assam, Judicial Department, Assam 3) Under Secretary to the Government of Assam, Judicial Department , Assam&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a3c53bea-8595-4934-889b-03578e062931</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>advt_2024/Advt_11_2024_v2.pdf</value>
      <webElementGuid>e2a36e87-a3fc-495a-b7cc-cb8068845874</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      1) Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam 
      2) Legal Assistant to Legal Remembrancer and Under Secretary to the Government of Assam, Judicial Department, Assam 
      3) Under Secretary to the Government of Assam, Judicial Department , Assam
    </value>
      <webElementGuid>97d30e6c-b411-4bf5-b597-aab7243dc5c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;footer-info&quot;)/div[@class=&quot;col-sm-6&quot;]/marquee[1]/ul[@class=&quot;scroll-updates&quot;]/li[3]/a[1]</value>
      <webElementGuid>7c088fc1-9c7a-48a5-b028-9e14d097bb65</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='footer-info']/div[2]/marquee/ul/li[3]/a</value>
      <webElementGuid>832353f4-f298-4573-a4a3-495695d62111</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADVT. NO. 11/2024'])[1]/following::a[1]</value>
      <webElementGuid>cab96f72-bc0b-4836-a2ef-8756c79baaeb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION START DATE:15-06-2024'])[2]/following::a[1]</value>
      <webElementGuid>a3bdf5a4-e354-4070-b5c2-d0a79f55235c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY HERE'])[3]/preceding::a[1]</value>
      <webElementGuid>9de24ac6-f0d1-4ff0-8801-54f0a86f911a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION START DATE:06-06-2024'])[1]/preceding::a[2]</value>
      <webElementGuid>e34881dd-c74c-4252-b931-e616fd4d2ea1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='1) Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam']/parent::*</value>
      <webElementGuid>16fd8df9-26c2-43e1-acd3-3d2bd0a2d7f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'advt_2024/Advt_11_2024_v2.pdf')]</value>
      <webElementGuid>9537566f-dd6d-4eb9-8ce4-8b3fc39a27f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//marquee/ul/li[3]/a</value>
      <webElementGuid>13c4cbc8-389c-4d6e-88bd-35ea4fa7273f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'advt_2024/Advt_11_2024_v2.pdf' and (text() = '
      1) Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam 
      2) Legal Assistant to Legal Remembrancer and Under Secretary to the Government of Assam, Judicial Department, Assam 
      3) Under Secretary to the Government of Assam, Judicial Department , Assam
    ' or . = '
      1) Junior Legislative Counsel and Under Secretary to the Government of Assam, Legislative Department, Assam 
      2) Legal Assistant to Legal Remembrancer and Under Secretary to the Government of Assam, Judicial Department, Assam 
      3) Under Secretary to the Government of Assam, Judicial Department , Assam
    ')]</value>
      <webElementGuid>28d73488-102a-486f-af6f-906d21ae2275</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
