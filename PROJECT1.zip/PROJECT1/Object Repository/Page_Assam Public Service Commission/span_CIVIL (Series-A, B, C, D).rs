<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_CIVIL (Series-A, B, C, D)</name>
   <tag></tag>
   <elementGuidId>290ce0dc-5d4b-452c-86e4-44debc176862</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr/td[2]/a[3]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(3) > span.label.label-warning</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;CIVIL (Series-A, B, C, D)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4a9fa854-c88c-4523-b9e8-24b8f6cceade</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-warning</value>
      <webElementGuid>17c65175-643d-4d4a-be30-2bbbf584af87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CIVIL (Series-A, B, C, D)</value>
      <webElementGuid>93ae9ea3-ede9-46aa-8069-1628c99c5325</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[1]/td[2]/a[3]/span[@class=&quot;label label-warning&quot;]</value>
      <webElementGuid>7e5c389c-f82d-4ad2-918c-2a5d560e256f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr/td[2]/a[3]/span</value>
      <webElementGuid>68e2b5e0-083f-463c-ae4d-3034a1b5fe07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MECHANICAL (Series-A, B, C, D)'])[1]/following::span[1]</value>
      <webElementGuid>3990621a-1a41-477f-817f-b60064c6c0b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NOTIFICATION'])[1]/following::span[2]</value>
      <webElementGuid>844a9068-3766-435d-90d9-225f0d89c674</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ELECTRICAL (Series-A, B, C, D)'])[1]/preceding::span[1]</value>
      <webElementGuid>1ee2d9e0-47b5-4444-90b7-afa9498e80c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CHEMICAL (Series-A, B, C, D)'])[1]/preceding::span[2]</value>
      <webElementGuid>e8896a45-f928-4d2d-8537-1900e8ec4b33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CIVIL (Series-A, B, C, D)']/parent::*</value>
      <webElementGuid>1e54833f-8190-4419-a902-9d815b9ef048</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[3]/span</value>
      <webElementGuid>b63bacab-1d65-490b-96a1-76ad671b1af4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'CIVIL (Series-A, B, C, D)' or . = 'CIVIL (Series-A, B, C, D)')]</value>
      <webElementGuid>0a682574-0389-42db-9fc9-631878715d89</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
