<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Previous Question Papers</name>
   <tag></tag>
   <elementGuidId>4ad8fc25-7d61-472e-9c32-d554e71c1ea4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='imp-links']/div/div[2]/div/a[8]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Previous Question Papers&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>35da0626-de53-41ed-a120-5bef9f258a68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>questions_2023.asp</value>
      <webElementGuid>6bde31fb-bf3b-4e64-b0cd-6eb49d2c281f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item imp-link</value>
      <webElementGuid>7232aa4f-2f50-496f-951f-a07664ab2b3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Previous Question Papers</value>
      <webElementGuid>59cda5e5-5961-46ab-aaa2-b1e2be1139bf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;imp-links&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;list-group&quot;]/a[@class=&quot;list-group-item imp-link&quot;]</value>
      <webElementGuid>cd5abe79-c2ce-4c8a-a106-8f5d2a94016e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='imp-links']/div/div[2]/div/a[8]</value>
      <webElementGuid>225cf30a-cda0-461b-92f5-11f9fef76d1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Previous Question Papers')]</value>
      <webElementGuid>4474f5bf-1b21-4f12-86f0-455f20b6650e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Answer Keys'])[1]/following::a[1]</value>
      <webElementGuid>ffadb669-a5dc-46dd-bc8b-3679a5e3f5ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Call Letters/Admit Cards'])[1]/following::a[2]</value>
      <webElementGuid>ce2938c7-ab74-4a55-8af0-6441562d108e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written/Screening Test Results'])[1]/preceding::a[1]</value>
      <webElementGuid>65cca14f-09fb-4667-8b7b-6956ab3b18c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Results'])[1]/preceding::a[2]</value>
      <webElementGuid>34724b6e-3e9a-43d4-9df0-960fc0dbe4cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Previous Question Papers']/parent::*</value>
      <webElementGuid>469b6e3d-3ad4-434e-bba4-84935b634a4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'questions_2023.asp')]</value>
      <webElementGuid>4263ec08-2097-4ac8-aacb-1457b6de2cdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[8]</value>
      <webElementGuid>158b770f-0012-470e-8195-d50029230ff9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'questions_2023.asp' and (text() = 'Previous Question Papers' or . = 'Previous Question Papers')]</value>
      <webElementGuid>e8d8118a-9a45-4944-a229-ff2d136cb165</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
