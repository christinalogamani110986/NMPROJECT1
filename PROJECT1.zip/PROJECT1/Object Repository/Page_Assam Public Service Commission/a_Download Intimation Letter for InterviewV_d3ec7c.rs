<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Download Intimation Letter for InterviewV_d3ec7c</name>
   <tag></tag>
   <elementGuidId>56660e06-05a6-4261-b672-23bc475dcfab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='admit_arch']/tbody/tr[4]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(4) > td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>113ef0cd-1d2e-4065-9d47-f8e6ead75c6d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://apscrecruitment.in/#/auth/download-intimation-letter/08db70a2-fd6a-4f54-8f5b-5cbb1effc389/Junior%20Information%20&amp;%20Public%20Relations%20Officer</value>
      <webElementGuid>9aede7cb-df9f-4a08-987c-1ca8dd20eca0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)</value>
      <webElementGuid>b7dcc45d-bb8a-42d0-8f03-073e6495af23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;admit_arch&quot;)/tbody[1]/tr[4]/td[2]/a[1]</value>
      <webElementGuid>1f45fd63-58e3-4c60-9c67-3b5a95d2ce42</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='admit_arch']/tbody/tr[4]/td[2]/a</value>
      <webElementGuid>641733d5-9718-4f0b-a734-8df66423c68e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)')]</value>
      <webElementGuid>a3823871-7632-4fe2-ab56-3f1f391657d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post'])[1]/following::a[3]</value>
      <webElementGuid>0868e056-bfd8-4d66-b248-c3838228458a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SL No.'])[1]/following::a[3]</value>
      <webElementGuid>85717fe2-bfa7-440a-90f6-4f4e38295aa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MECHANICAL'])[1]/preceding::a[9]</value>
      <webElementGuid>5cb68105-1109-4e9e-992a-5b9089f3e2e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CIVIL'])[1]/preceding::a[10]</value>
      <webElementGuid>6ccfbefd-e316-4286-9545-fe30e768fc8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)']/parent::*</value>
      <webElementGuid>ef46e18c-6a9f-4149-8897-96fe3c71ba3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://apscrecruitment.in/#/auth/download-intimation-letter/08db70a2-fd6a-4f54-8f5b-5cbb1effc389/Junior%20Information%20&amp;%20Public%20Relations%20Officer')]</value>
      <webElementGuid>9c154479-9a7d-4221-939d-e32372ab5834</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td[2]/a</value>
      <webElementGuid>8735dec2-e7e8-4b59-8b0f-8849ab5cce4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://apscrecruitment.in/#/auth/download-intimation-letter/08db70a2-fd6a-4f54-8f5b-5cbb1effc389/Junior%20Information%20&amp;%20Public%20Relations%20Officer' and (text() = 'Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)' or . = 'Download Intimation Letter for Interview/Viva-Voce for the post of Junior Information &amp; Public Relations Officer under Information, Public Relations, Printing &amp; Stationery Department, Assam (Advt. No. 19/2023, dtd 03-06-2023)')]</value>
      <webElementGuid>c91a252a-8d96-47d5-b309-0ecb7e904689</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
