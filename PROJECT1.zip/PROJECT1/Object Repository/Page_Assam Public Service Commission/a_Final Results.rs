<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Final Results</name>
   <tag></tag>
   <elementGuidId>6f035aa0-7810-4bc9-a7a8-e19fc161e525</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='imp-links']/div/div[2]/div/a[10]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Final Results&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ac21b56b-c9e3-452d-a0ff-433d9986e8d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>final-results-2024.asp#final_result</value>
      <webElementGuid>8ea13cdf-675f-402b-8c09-f4fca7c59106</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item imp-link</value>
      <webElementGuid>b8013e7b-c2bf-48a2-b63d-4e7b68545b36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Final Results</value>
      <webElementGuid>44ffe166-e21d-404e-952f-191cfd072dea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;imp-links&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;list-group&quot;]/a[@class=&quot;list-group-item imp-link&quot;]</value>
      <webElementGuid>7a5839a7-8595-4c65-bb69-0dd2bf9c18b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='imp-links']/div/div[2]/div/a[10]</value>
      <webElementGuid>9827b794-641d-4d45-90f3-5c7d1d04cdce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Final Results')]</value>
      <webElementGuid>8b6cfa59-8052-4694-a30d-1ec875b2050f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written/Screening Test Results'])[1]/following::a[1]</value>
      <webElementGuid>b32f2c04-c17f-4b45-bb61-eb2bc36680b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Question Papers'])[1]/following::a[2]</value>
      <webElementGuid>19bcba02-1840-4bbb-bfae-0e962c4ce85d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/preceding::a[1]</value>
      <webElementGuid>0d70a91d-230c-486d-9564-a78e3de52beb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Question Papers'])[2]/preceding::a[2]</value>
      <webElementGuid>0768021d-9fc1-4c68-b3d8-78375ec1f258</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Final Results']/parent::*</value>
      <webElementGuid>2a30f912-24c8-475b-a8c7-13b34975cdcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'final-results-2024.asp#final_result')]</value>
      <webElementGuid>5f937684-dbbe-464d-8571-6edae82c06d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[10]</value>
      <webElementGuid>53abcfd6-4899-4461-85cc-19e016b910ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'final-results-2024.asp#final_result' and (text() = 'Final Results' or . = 'Final Results')]</value>
      <webElementGuid>e648b7d8-0b1a-42c0-8a08-e630265d45a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
