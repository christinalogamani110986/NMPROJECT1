<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Photo Gallery</name>
   <tag></tag>
   <elementGuidId>1a77a99f-e364-4690-9eca-84d9b746ab45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='imp-links']/div/div[2]/div/a[11]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Photo Gallery&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>20de4941-5e47-499e-80c8-1510e6ca8f6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>view_gallery.asp#gallery</value>
      <webElementGuid>fee21832-4eb3-423a-84f7-3f15d1cc327b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item imp-link</value>
      <webElementGuid>dbcd8ea4-8fee-4df9-bfc4-9359e6ca4acb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Photo Gallery</value>
      <webElementGuid>57a34704-f598-40ed-a655-6c9eb663edf5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;imp-links&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;list-group&quot;]/a[@class=&quot;list-group-item imp-link&quot;]</value>
      <webElementGuid>7b7a3af6-89d1-4def-a134-7d44ef8eb238</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='imp-links']/div/div[2]/div/a[11]</value>
      <webElementGuid>d4523591-4028-4fc2-a321-3203b728c55e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Photo Gallery')]</value>
      <webElementGuid>c9c52797-332c-4a35-8939-194c1d994f63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Results'])[1]/following::a[1]</value>
      <webElementGuid>cf743b8f-d807-4c58-aea2-a8b7a19459be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written/Screening Test Results'])[1]/following::a[2]</value>
      <webElementGuid>56ca78ca-eb45-4b3d-9797-b3f48c3bdd7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SL'])[1]/preceding::a[9]</value>
      <webElementGuid>42428919-82de-4719-a68f-d3a65ec3c5dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Photo Gallery']/parent::*</value>
      <webElementGuid>cb8e1bba-2be4-49ce-ad09-ff32c3ef822e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'view_gallery.asp#gallery')]</value>
      <webElementGuid>d30c4080-09fd-4fab-a11d-caa31d833be0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[11]</value>
      <webElementGuid>9ac96585-6ae7-461b-8fa9-59c99e66c150</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'view_gallery.asp#gallery' and (text() = 'Photo Gallery' or . = 'Photo Gallery')]</value>
      <webElementGuid>d0b36f13-5447-4171-b071-9e1af094de85</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
