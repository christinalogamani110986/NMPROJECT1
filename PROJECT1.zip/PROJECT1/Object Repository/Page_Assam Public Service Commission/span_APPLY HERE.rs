<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_APPLY HERE</name>
   <tag></tag>
   <elementGuidId>cd5b1bff-8dd2-4618-a6bf-5966319be3c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='advertisement']/tbody/tr[2]/td[2]/a[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.label.label-success</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL) APPLY HEREAPPLICATION START DATE:15-06-2024&quot;i] >> internal:role=link >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b3dd5a52-5a2f-41fd-815b-919cfc9d2989</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label label-success</value>
      <webElementGuid>f843b7d0-0eb7-4047-8c1c-e92e45df9df7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>APPLY HERE</value>
      <webElementGuid>9d689e18-32d7-4440-ab6e-a24f20343481</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;advertisement&quot;)/tbody[1]/tr[@class=&quot;advt_rw&quot;]/td[2]/a[2]/span[@class=&quot;label label-success&quot;]</value>
      <webElementGuid>93f85642-10ce-419d-8694-6eef1017a307</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='advertisement']/tbody/tr[2]/td[2]/a[2]/span</value>
      <webElementGuid>84fcb833-375d-456f-b5c2-b052ff2bf439</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Closing Date'])[1]/following::span[1]</value>
      <webElementGuid>fa58b215-88ba-46a5-bca8-121f2a8f72ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Published Date'])[1]/following::span[1]</value>
      <webElementGuid>a2e4b277-eb2b-4b63-8736-8dd0ea5e14a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION START DATE:15-06-2024'])[1]/preceding::span[1]</value>
      <webElementGuid>b1322867-c4b8-4db8-8e2e-a614d3ca9f47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY HERE'])[2]/preceding::span[2]</value>
      <webElementGuid>b548bfa7-e2ac-4598-9fb9-b56fc1f5fb05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='APPLY HERE']/parent::*</value>
      <webElementGuid>577f6c51-ed26-479a-9f34-194c954e9f76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]/span</value>
      <webElementGuid>12c5ef6a-a90d-4d3f-927d-03398e274654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'APPLY HERE' or . = 'APPLY HERE')]</value>
      <webElementGuid>9de1e5a1-2f25-451a-b203-f6bad9c8daff</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
