<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_The Commission</name>
   <tag></tag>
   <elementGuidId>1e6313bf-27ce-43ea-9390-567986152f16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;The Commission&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ddeb897d-69a4-4b16-b4da-0993ae59e7d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>commission.asp#commission</value>
      <webElementGuid>caf84fa9-8a10-4179-a026-232b548de8d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The Commission</value>
      <webElementGuid>12f33449-1616-4add-aadd-ab070a60720a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/table[@class=&quot;table table-condensed table-bordered table-striped&quot;]/tbody[1]/tr[2]/td[2]/a[1]</value>
      <webElementGuid>e793addb-f9c3-4029-9182-f44b89c26d58</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div[2]/table/tbody/tr[2]/td[2]/a</value>
      <webElementGuid>9482e19d-0fa4-4c12-8304-b67793d98029</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'The Commission')])[2]</value>
      <webElementGuid>d6de5cf3-2996-4e0e-9ced-05fc11b0cbb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/following::a[1]</value>
      <webElementGuid>56cf7970-41b5-4b26-ae22-b48d8fda6566</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sl. No.'])[1]/following::a[1]</value>
      <webElementGuid>1909d108-5638-4efc-b7a4-c0a078642fbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Organizational Structure'])[1]/preceding::a[1]</value>
      <webElementGuid>9247e12f-a38a-45f4-9023-996913e9a776</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Statement of committees'])[1]/preceding::a[2]</value>
      <webElementGuid>1a79b5ac-df4e-4a12-a5b8-e160fdc7782a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'commission.asp#commission')])[2]</value>
      <webElementGuid>16769428-36ca-4526-b8c8-e3e0003057e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
      <webElementGuid>03f3bfa3-aac0-4a46-a1b5-302749f1faeb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'commission.asp#commission' and (text() = 'The Commission' or . = 'The Commission')]</value>
      <webElementGuid>3b2719c8-6735-4868-8c0b-4415b8a6a539</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul/li[2]/ul/li/a</value>
      <webElementGuid>0a331172-a878-42a8-bbe1-47d0c7674872</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'The Commission')]</value>
      <webElementGuid>f12d82fc-b480-4d31-ac0b-c54efd263c11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::a[2]</value>
      <webElementGuid>c7b87153-b320-4029-b075-0094a662ef80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='C'])[1]/following::a[3]</value>
      <webElementGuid>9264a934-4088-4229-b780-b08a883c646e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision and Mission'])[1]/preceding::a[1]</value>
      <webElementGuid>997d8360-1c3a-4d4f-9b23-89ae12995803</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Historical Perspective'])[1]/preceding::a[2]</value>
      <webElementGuid>45b04278-7828-4d9d-8a7f-a5b2d2b0f96a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The Commission']/parent::*</value>
      <webElementGuid>7e8afc15-9bd5-4a7c-9273-87f438ef9d14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'commission.asp#commission')]</value>
      <webElementGuid>b1a155a0-1f49-4dcf-aa74-4f18d16b70d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li/a</value>
      <webElementGuid>46ddb236-755f-4103-a060-f3e9c7162b44</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
