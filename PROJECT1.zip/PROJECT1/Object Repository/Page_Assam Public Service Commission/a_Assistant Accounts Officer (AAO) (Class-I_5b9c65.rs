<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Assistant Accounts Officer (AAO) (Class-I_5b9c65</name>
   <tag></tag>
   <elementGuidId>3c3c9213-6bef-44f4-be8d-a1e742675a53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='footer-info']/div[2]/marquee/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.scroll-updates > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d64dbb9f-8226-4650-b261-41fc2f36846d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>advt_2024/Advt_No_13_2024.pdf</value>
      <webElementGuid>4ac16396-b00d-4b14-8529-6fdfc2044817</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)
    </value>
      <webElementGuid>83ed88fe-a060-40d8-9621-36cd180dfc27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;footer-info&quot;)/div[@class=&quot;col-sm-6&quot;]/marquee[1]/ul[@class=&quot;scroll-updates&quot;]/li[1]/a[1]</value>
      <webElementGuid>0cd92f5f-2b0c-4646-8856-0804eae21a8c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='footer-info']/div[2]/marquee/ul/li/a</value>
      <webElementGuid>cd41e6d5-8728-490c-ac61-5e73dee1ec01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)')]</value>
      <webElementGuid>2ba46189-e3a8-4ebc-8bc8-8456e176c919</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADVT. NO. 13/2024'])[1]/following::a[1]</value>
      <webElementGuid>5b8d5b9f-af10-4526-a0c0-1e4fce8c5524</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Public Administration Paper - I'])[1]/following::a[2]</value>
      <webElementGuid>09fb313c-7a03-4b2c-9926-ad978d27aed8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY HERE'])[1]/preceding::a[1]</value>
      <webElementGuid>e95293f4-a23f-4f5f-97c8-e199eb82246e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION START DATE:15-06-2024'])[1]/preceding::a[2]</value>
      <webElementGuid>6cabf942-f511-416a-bbb5-686c52343c21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)']/parent::*</value>
      <webElementGuid>3bd4e35d-9b17-4d83-83f3-bd58c80ca074</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'advt_2024/Advt_No_13_2024.pdf')]</value>
      <webElementGuid>b82e1f6c-c762-4c83-a8e5-b3cb15a255e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//marquee/ul/li/a</value>
      <webElementGuid>d9fbca26-480c-4427-bc74-21b7ffdda195</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'advt_2024/Advt_No_13_2024.pdf' and (text() = '
      Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)
    ' or . = '
      Assistant Accounts Officer (AAO) (Class-III post) of Assam Power Distribution Company Limited (APDCL)
    ')]</value>
      <webElementGuid>8098b06e-abe3-4449-a402-cb706a6dbc4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
