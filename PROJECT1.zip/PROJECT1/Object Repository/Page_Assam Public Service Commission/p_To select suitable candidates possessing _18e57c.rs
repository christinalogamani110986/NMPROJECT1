<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_To select suitable candidates possessing _18e57c</name>
   <tag></tag>
   <elementGuidId>e2cfbeb7-29ff-4283-95a2-98dd911efa81</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='updates']/div/div/div[2]/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.panel-body > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;To select suitable candidates possessing the requisite educational qualification&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>8fa6d0cc-c866-48cf-a1af-4a0ba56b101d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            To select suitable candidates possessing the requisite educational qualifications, skills and motivation to serve the people of Assam for the assigned government jobs through a transparent, fair, scintific and time-bound recruitment process thereby making quality and integrity the defining characteristics of the personnel selected.
          </value>
      <webElementGuid>379380ca-4e27-413e-8b63-6b7dcb738912</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;updates&quot;)/div[@class=&quot;panel-group&quot;]/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body&quot;]/p[1]</value>
      <webElementGuid>fe99783e-028d-4774-8ae7-deeccc9aed21</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='updates']/div/div/div[2]/p</value>
      <webElementGuid>0cb7a386-1c20-4fac-af7e-18f9872b23d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision and Mission'])[2]/following::p[1]</value>
      <webElementGuid>ab3e59c5-40c5-47fe-851d-b02492d983ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/following::p[1]</value>
      <webElementGuid>f8087fa5-ad76-444f-8442-0552fd50c12c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Composition of the Commission'])[1]/preceding::p[1]</value>
      <webElementGuid>df95a482-0bb8-4aa0-988c-3d6188d6bef5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Present incumbents of the Commission'])[1]/preceding::p[2]</value>
      <webElementGuid>64eed462-77af-4e96-8606-12c794e3e295</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='To select suitable candidates possessing the requisite educational qualifications, skills and motivation to serve the people of Assam for the assigned government jobs through a transparent, fair, scintific and time-bound recruitment process thereby making quality and integrity the defining characteristics of the personnel selected.']/parent::*</value>
      <webElementGuid>1cda971b-6944-478b-9159-e2a7c6819409</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p</value>
      <webElementGuid>6ecbd892-e23d-4b09-ad3f-db1f5c89c4bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
            To select suitable candidates possessing the requisite educational qualifications, skills and motivation to serve the people of Assam for the assigned government jobs through a transparent, fair, scintific and time-bound recruitment process thereby making quality and integrity the defining characteristics of the personnel selected.
          ' or . = '
            To select suitable candidates possessing the requisite educational qualifications, skills and motivation to serve the people of Assam for the assigned government jobs through a transparent, fair, scintific and time-bound recruitment process thereby making quality and integrity the defining characteristics of the personnel selected.
          ')]</value>
      <webElementGuid>55296a90-77f3-4fd2-b2d6-8f3f1bfcfdc1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
